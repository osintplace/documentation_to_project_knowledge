# Webhooks

Webhooks allow n8n to receive real-time data from other services. You can trigger workflows using webhooks that wait for HTTP requests.

---

# Authentication

Authentication in n8n is handled through credentials. You can define OAuth2, API Key, or basic auth credentials per service.

---
